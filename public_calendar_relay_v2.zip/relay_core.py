"""Canonical PUBLIC calendar bundle construction and independent verification."""
import base64
from datetime import datetime,timedelta,date,time,timezone
import hashlib
import json
from pathlib import Path
import re
import uuid
import public_calendar as c

SCHEMA='official-public-calendar-relay'
VERSION=1
MAX_AGE=timedelta(hours=36)


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()+b'\n'


def strict_json(data):
    def pairs(items):
        output={}
        for key,value in items:
            c.require(key not in output,'Duplicate JSON property');output[key]=value
        return output
    def bad(value):raise c.InvalidCalendar('Nonfinite JSON number')
    return json.loads(data,object_pairs_hook=pairs,parse_constant=bad)


def stamp(value):
    at=datetime.fromisoformat(value)
    c.require(at.tzinfo is not None,'Timezone-aware provenance required')
    return at


def pair(start,end,sources,manifest,generated):
    macro,sessions=c.build(start,end,sources,generated)
    generation=c.sha(canonical(manifest))[:32]
    for data in (macro,sessions):data['generation']=generation;data['source_provenance']=manifest
    for row in macro['days'].values():
        row['source_verification']=manifest
        row['retrieved_at']=max(r['retrieved_at'] for r in manifest.values())
    for row in sessions['days'].values():row['retrieved_at']=manifest['nyse']['retrieved_at']
    return macro,sessions


def create_bundle(observed=None,get=c.fetch):
    started=observed or datetime.now(c.ET)
    start=started.astimezone(c.ET).date();end=min(start+timedelta(days=13),date(start.year,12,31))
    sources={};manifest={};failures={}
    urls=c.urls_for(start,end);secondary=c.bls_secondary_urls(start,end)
    for name,url in (urls|secondary).items():
        try:
            data=get(url)
            sources[name]=bytes(data)
            at=getattr(data,'metadata',{}).get('retrieved_at') or (started if observed else datetime.now(c.ET)).isoformat()
            manifest[name]=dict(url=url,retrieved_at=at,sha256=c.sha(data),bytes=len(data),
                               content_type='text/calendar' if name=='bls_ics' else 'text/html')
        except c.SourceUnavailable as exc:
            failures[name]=dict(url=url,error=str(exc))
            c.require(name=='bls_ics' or name in secondary,'Required source unavailable: '+name)
        # Validation errors, including HTTP-200 wrong content, propagate. They
        # must never become an apparent transport failure that a fallback masks.
    generated=started if observed else datetime.now(c.ET)
    macro,sessions=pair(start,end,sources,manifest,generated)
    bundle=dict(schema=SCHEMA,version=VERSION,generated_at=generated.isoformat(),
        coverage_start=start.isoformat(),coverage_end=end.isoformat(),policy=c.POLICY,
        source_manifest=manifest,source_captures={key:base64.b64encode(value).decode() for key,value in sources.items()},
        retrieval_failures=failures,macro_calendar=macro,sessions=sessions)
    body=canonical(bundle)
    verify_bundle(body,c.sha(body),generated)
    return body


def verify_bundle(body,expected_hash,now=None):
    now=now or datetime.now(c.ET)
    c.require(re.fullmatch(r'[0-9a-f]{64}',expected_hash or '') is not None,'Invalid bundle hash')
    c.require(0<len(body)<32_000_000 and c.sha(body)==expected_hash,'Bundle SHA-256 mismatch/size')
    bundle=strict_json(body)
    c.require(body==canonical(bundle),'Noncanonical bundle JSON')
    required={'schema','version','generated_at','coverage_start','coverage_end','policy','source_manifest',
              'source_captures','retrieval_failures','macro_calendar','sessions'}
    c.require(set(bundle)==required and bundle['schema']==SCHEMA and type(bundle['version']) is int
              and bundle['version']==VERSION and bundle['policy']==c.POLICY,'Unexpected bundle schema/version/policy')
    generated=stamp(bundle['generated_at'])
    c.require(-timedelta(seconds=60)<=now-generated<=MAX_AGE,'Stale/future relay bundle')
    start=date.fromisoformat(bundle['coverage_start']);end=date.fromisoformat(bundle['coverage_end'])
    c.require(start==generated.astimezone(c.ET).date() and end==min(start+timedelta(days=13),date(start.year,12,31)),
              'Unexpected verified coverage horizon')
    urls=c.urls_for(start,end)|c.bls_secondary_urls(start,end)
    manifest=bundle['source_manifest'];captures=bundle['source_captures'];sources={}
    c.require(isinstance(manifest,dict) and set(manifest)==set(captures) and set(manifest)<=set(urls),
              'Missing/unknown source provenance')
    for key,record in manifest.items():
        c.require(set(record)=={'url','retrieved_at','sha256','bytes','content_type'} and record['url']==urls[key],
                  'Official source provenance mismatch: '+key)
        retrieved=stamp(record['retrieved_at'])
        c.require(timedelta(0)<=generated-retrieved<=timedelta(hours=1),'Invalid source retrieval timestamp')
        c.require(record['content_type']==('text/calendar' if key=='bls_ics' else 'text/html'),'Wrong source type')
        raw=base64.b64decode(captures[key],validate=True)
        c.require(0<len(raw)<10_000_000 and type(record['bytes']) is int and len(raw)==record['bytes']
                  and c.sha(raw)==record['sha256'],'Source content/hash mismatch: '+key)
        sources[key]=raw
    # Reparse ALL exact source bytes. No executable/serialized objects from the
    # publisher are evaluated. Unverified empty days and tampered sessions fail.
    macro,sessions=pair(start,end,sources,manifest,generated)
    c.require(bundle['macro_calendar']==macro and bundle['sessions']==sessions,
              'Calendar rows do not match independently parsed official captures')
    return bundle


def publish(output,body,now=None):
    output=Path(output);digest=c.sha(body);bundle=verify_bundle(body,digest,now)
    manifest=canonical(dict(schema=SCHEMA+'-sources',version=VERSION,generated_at=bundle['generated_at'],
                            bundle_sha256=digest,sources=bundle['source_manifest']))
    files={'calendar_bundle.json':body,'calendar_bundle.sha256':(digest+'  calendar_bundle.json\n').encode(),
           'source_manifest.json':manifest}
    generation=output/'generations'/digest;generation.mkdir(parents=True,exist_ok=True)
    for name,data in files.items():
        path=generation/name
        if path.exists():c.require(path.read_bytes()==data,'Immutable published generation conflict')
        else:c.atomic(path,data)
    for name,data in files.items():c.atomic(output/name,data)
    # Consumers resolve this atomic pointer and fetch one immutable generation.
    c.atomic(output/'latest.json',canonical(dict(schema=SCHEMA,version=VERSION,
        generated_at=bundle['generated_at'],sha256=digest,path='generations/'+digest)))
    return digest


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('public'))
    args=parser.parse_args()
    # A source/validation failure occurs BEFORE publish; no Pages artifact is
    # uploaded/deployed and the last successful public deployment stays active.
    body=create_bundle();print(publish(args.output,body))
