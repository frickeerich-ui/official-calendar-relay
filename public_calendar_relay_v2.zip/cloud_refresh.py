"""Public-only cloud retrieval; normal browser transport for official BLS data.

No login, challenge solving, proxy rotation, unofficial data or stale bootstrap
fallback. A blocked browser request fails the refresh and preserves publication.
"""
import argparse
from datetime import datetime
from pathlib import Path
import tempfile
import public_calendar as c
import relay_core as r

class OfficialBrowser:
    def __enter__(self):
        from playwright.sync_api import sync_playwright
        self.runtime=sync_playwright().start()
        self.browser=self.runtime.chromium.launch(headless=True)
        self.context=self.browser.new_context(accept_downloads=True,
            extra_http_headers={'X-Calendar-Client':'OfficialCalendarRelay/1.2; public scheduled data'})
        return self
    def __exit__(self,*args):self.browser.close();self.runtime.stop()
    def fetch(self,url):
        c.require(url==c.BLS_ICS or url in c.bls_secondary_urls(datetime.now(c.ET).date(),
            datetime.now(c.ET).date()+__import__('datetime').timedelta(days=13)).values(),'Browser source outside approved BLS policy')
        page=self.context.new_page();responses=[]
        page.on('response',lambda response:responses.append(response) if response.url==url else None)
        try:
            if url==c.BLS_ICS:
                from playwright.sync_api import Error
                try:
                    with page.expect_download(timeout=25000) as pending:
                        try:page.goto(url,wait_until='commit',timeout=25000)
                        except Error as exc:
                            if 'Download is starting' not in str(exc):raise
                    download=pending.value
                except Exception as exc:
                    raise c.SourceUnavailable('Official BLS browser download unavailable') from exc
                c.require(responses and responses[-1].status==200,'Official BLS browser response not HTTP 200')
                c.require(responses[-1].headers.get('content-type','').split(';')[0].strip().lower()=='text/calendar','Official browser returned non-calendar content')
                with tempfile.TemporaryDirectory(prefix='official-bls-') as folder:
                    path=Path(folder)/'bls.ics';download.save_as(path);data=path.read_bytes()
            else:
                response=page.goto(url,wait_until='domcontentloaded',timeout=25000)
                if response is None or response.status!=200:raise c.SourceUnavailable('Official BLS browser HTML unavailable')
                c.require(response.headers.get('content-type','').split(';')[0].strip().lower()=='text/html','Official browser returned non-HTML content')
                data=response.body()
            c.require(100<len(data)<10_000_000,'Official browser source size invalid')
            return c.Capture(data,dict(retrieved_at=datetime.now(c.ET).isoformat()))
        finally:page.close()

def refresh(output,browser_factory=OfficialBrowser,get=c.fetch):
    with browser_factory() as browser:
        def retrieve(url):
            try:return get(url)
            except c.SourceUnavailable:
                if url.startswith('https://www.bls.gov/'):return browser.fetch(url)
                raise
        body=r.create_bundle(get=retrieve)
    return r.publish(output,body)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('public'))
    p.add_argument('--verified-bootstrap',type=Path)
    args=p.parse_args()
    if args.verified_bootstrap:
        # Explicit one-time dispatch only. Original timestamps/hashes retained;
        # it is never an automatic fallback after required-source failure.
        body=(args.verified_bootstrap/'calendar_bundle.json').read_bytes()
        print(r.publish(args.output,body))
    else:print(refresh(args.output))
