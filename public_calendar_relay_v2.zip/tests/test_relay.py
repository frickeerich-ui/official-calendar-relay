"""Synthetic BLS acceptance fixtures; never published as real calendar data."""
import base64
from datetime import datetime,timedelta
import json
from pathlib import Path
import socket
import tempfile
import unittest
from unittest.mock import patch
import public_calendar as c
import relay_core as r

HERE=Path(__file__).resolve().parent
NOW=datetime(2026,11,15,18,tzinfo=c.ET)


def captures():
    data={name:(HERE/'fixtures'/(name+'.html')).read_bytes() for name in ('census','fed','bea','dol','nyse')}
    data['bls']=(HERE/'fixtures'/'SYNTHETIC_bls.ics').read_bytes()
    urls=c.urls_for(NOW.date(),NOW.date()+timedelta(days=13))
    mapped={url:data['bls' if key=='bls_ics' else key.split('_')[0]] for key,url in urls.items()}
    return mapped


def getter(data):
    def get(url):
        if url not in data:raise c.SourceUnavailable('Unavailable optional official HTML')
        return data[url]
    return get


class RelayTests(unittest.TestCase):
    def setUp(self):
        self.data=captures();self.body=r.create_bundle(NOW,getter(self.data));self.hash=c.sha(self.body)
        self.deny=patch.object(socket,'socket',side_effect=AssertionError('No network in relay tests'));self.deny.start()
    def tearDown(self):self.deny.stop()
    def changed(self,mutate):
        value=r.strict_json(self.body);mutate(value);body=r.canonical(value);return body,c.sha(body)
    def test_success_reparsed_coverage(self):
        result=r.verify_bundle(self.body,self.hash,NOW)
        self.assertIn('2026-11-27',result['macro_calendar']['days'])
        self.assertTrue(result['macro_calendar']['days']['2026-11-16']['verified_no_events'])
    def test_bls_failure_does_not_publish(self):
        self.data.pop(c.BLS_ICS)
        with self.assertRaises(c.InvalidCalendar):r.create_bundle(NOW,getter(self.data))
    def test_other_required_source_failure(self):
        self.data.pop('https://www.bea.gov/news/schedule/')
        with self.assertRaises(c.InvalidCalendar):r.create_bundle(NOW,getter(self.data))
    def test_malformed_output(self):
        for body in (b'{}',b'<html>error</html>',b'{"version":1,"version":1}'):
            with self.subTest(body=body),self.assertRaises((ValueError,c.InvalidCalendar)):
                r.verify_bundle(body,c.sha(body),NOW)
    def test_stale_output(self):
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(self.body,self.hash,NOW+timedelta(hours=37))
    def test_future_output(self):
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(self.body,self.hash,NOW-timedelta(minutes=2))
    def test_wrong_hash(self):
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(self.body,'0'*64,NOW)
    def test_missing_provenance(self):
        body,digest=self.changed(lambda b:b['source_manifest'].pop('bls_ics'))
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(body,digest,NOW)
    def test_wrong_source_origin(self):
        body,digest=self.changed(lambda b:b['source_manifest']['bls_ics'].update(url='https://example.com/bls.ics'))
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(body,digest,NOW)
    def test_source_hash_mismatch(self):
        body,digest=self.changed(lambda b:b['source_manifest']['bls_ics'].update(sha256='0'*64))
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(body,digest,NOW)
    def test_duplicate_event(self):
        body,digest=self.changed(lambda b:b['macro_calendar']['days']['2026-11-17']['events'].append(
            b['macro_calendar']['days']['2026-11-17']['events'][0]))
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(body,digest,NOW)
    def test_timezone_handling(self):
        b=r.verify_bundle(self.body,self.hash,NOW)
        row=next(e for e in b['macro_calendar']['days']['2026-11-17']['events'] if e['source']==c.BLS_ICS)
        self.assertTrue(row['dt'].endswith('08:30:00-05:00'))
        self.assertEqual(c.ics_datetime('20260701T083000',{'TZID':'US-Eastern'}).utcoffset(),timedelta(hours=-4))
    def test_early_close_and_holiday(self):
        b=r.verify_bundle(self.body,self.hash,NOW)
        self.assertEqual(b['sessions']['days']['2026-11-27']['close'],'2026-11-27T13:00:00-05:00')
        self.assertNotIn('2026-11-26',b['sessions']['days'])
        body,digest=self.changed(lambda b:b['sessions']['days']['2026-11-27'].update(close='2026-11-27T16:00:00-05:00'))
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(body,digest,NOW)
    def test_cannot_invent_verified_empty_date(self):
        body,digest=self.changed(lambda b:b['macro_calendar']['days']['2026-11-17'].update(events=[],verified_no_events=True))
        with self.assertRaises(c.InvalidCalendar):r.verify_bundle(body,digest,NOW)
    def test_atomic_pointer_publication(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);r.publish(root,self.body,NOW);before=(root/'latest.json').read_bytes()
            self.assertEqual(r.strict_json(before)['sha256'],self.hash)
            actual=c.atomic
            def fail(path,value):
                if Path(path).name=='latest.json':raise OSError('publication interrupted')
                return actual(path,value)
            with patch.object(c,'atomic',side_effect=fail),self.assertRaises(OSError):r.publish(root,self.body,NOW)
            self.assertEqual((root/'latest.json').read_bytes(),before)
    def test_required_source_failure_retains_published_bundle(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);r.publish(root,self.body,NOW)
            before={p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
            self.data.pop(c.BLS_ICS)
            with self.assertRaises(c.InvalidCalendar):r.publish(root,r.create_bundle(NOW,getter(self.data)),NOW)
            self.assertEqual({p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()},before)
    def test_no_private_trading_dependencies(self):
        for name in ('public_calendar.py','relay_core.py'):
            text=(HERE.parent/name).read_text(encoding='utf-8')
            for token in ('load_vault','alpaca.trading','compound_pool','account_id','EXPECTED_ACCOUNT',r'C:\Users'):
                self.assertNotIn(token,text)


if __name__=='__main__':unittest.main()
