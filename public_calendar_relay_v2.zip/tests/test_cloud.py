import sys,unittest
from unittest.mock import patch
import cloud_refresh as cloud
import public_calendar as c
import relay_core as relay
from test_relay import NOW,captures
from pathlib import Path
import tempfile

class Cloud(unittest.TestCase):
 def setUp(self):self.data=captures();self.browser_calls=[]
 def browser(self):
  outer=self
  class Browser:
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def fetch(self,url):
    outer.browser_calls.append(url)
    if url not in outer.data:raise c.SourceUnavailable('optional BLS HTML not accessible')
    return outer.data[url]
  return Browser()
 def direct(self,url):
  if url.startswith('https://www.bls.gov/'):raise c.SourceUnavailable('403')
  if url not in self.data:raise c.SourceUnavailable('required source unavailable')
  return self.data[url]
 def run_refresh(self):
  original=relay.create_bundle
  with tempfile.TemporaryDirectory() as folder,patch.object(cloud.r,'create_bundle',side_effect=lambda get:original(NOW,get)),patch.object(cloud.r,'publish',side_effect=lambda output,body:relay.verify_bundle(body,c.sha(body),NOW)):
   return cloud.refresh(Path(folder),self.browser,self.direct)
 def test_official_browser_fallback_success(self):
  self.assertEqual(self.run_refresh()['version'],1);self.assertIn(c.BLS_ICS,self.browser_calls)
 def test_bls_still_blocked_never_publishes(self):
  self.data.pop(c.BLS_ICS)
  with self.assertRaises(c.InvalidCalendar):self.run_refresh()
 def test_other_source_failure_never_uses_browser(self):
  self.data.pop('https://www.bea.gov/news/schedule/')
  with self.assertRaises(c.InvalidCalendar):self.run_refresh()
  self.assertFalse(self.browser_calls)
 def test_http_success_wrong_content_is_not_masked(self):
  def bad(url):raise c.InvalidCalendar('HTTP 200 wrong type')
  with tempfile.TemporaryDirectory() as folder,self.assertRaises(c.InvalidCalendar):cloud.refresh(Path(folder),self.browser,bad)
  self.assertFalse(self.browser_calls)
