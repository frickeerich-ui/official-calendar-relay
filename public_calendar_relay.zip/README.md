PUBLIC CALENDAR RELAY — standalone, data only

This package retrieves public BLS, Census, Federal Reserve, BEA, DOL and NYSE calendar data. It contains no trading PC paths, broker credentials, account identifiers, positions, orders, execution journals or trading actor code. It cannot authorize entries or operate a broker account.

The GitHub workflow runs at 04:17, 10:17, 16:17 and 22:17 UTC daily, and on a main-branch push or manual workflow dispatch. Each run makes one identifiable, bounded GET per required URL, plus official BLS monthly cross-check/fallback URLs. No unofficial aggregators or access-control bypasses are used. GitHub's scheduled execution can be delayed; freshness and coverage checks fail closed if publication stops.

The preferred BLS source is https://www.bls.gov/schedule/news_release/bls.ics. All required sources undergo the same strict parser and semantic coverage validation. The consumer independently reconstructs the calendars from exact public source captures. Missing required sources, malformed/empty/stale BLS data, date/time ambiguity, duplicate events, source disagreements and incomplete coverage prevent publication. The existing scheduled-release selection policy is carried as explicit public calendar metadata.

Successful builds produce:

- `calendar_bundle.json`: canonical JSON containing calendar rows, raw public source captures encoded as base64, and per-source provenance.
- `calendar_bundle.sha256`: SHA-256 of the exact canonical bundle bytes.
- `source_manifest.json`: exact official URLs, retrieval times, content hashes, lengths and content types, bound to the bundle hash.
- `latest.json`: atomic generation pointer.
- `generations/<bundle-sha256>/...`: immutable copies of the three bundle files.

This is HTTPS plus SHA-256 integrity verification, not a separate digital signature. The local consumer pins the configured GitHub Pages origin, checks every hash/timestamp/schema, and reparses every official capture. It accepts bundles at most 36 hours old and rejects future timestamps. A changing sidecar or unavailable immutable generation fails closed; it does not replace local calendars.

The Actions deployment job depends on a successful test/build job. It never runs on source or validation failure, leaving the last successful Pages deployment intact. No secret is required for source retrieval. GitHub's ephemeral repository token records a public generation/hash heartbeat on the main branch after each verified refresh; this supplies ongoing repository activity rather than relying on an operator to keep an otherwise inactive public repository's schedules enabled. Token-authored pushes do not recursively trigger this workflow. The separate deployment job uses ordinary Pages permissions. Protect workflow/code changes while permitting these public heartbeat commits during the one-time hosting setup.

One-time deployment:

1. Create a new, empty **public** GitHub repository containing only this package. Do not upload the Alpaca project, audit folders, production files or parent directories.
2. Push/upload these files to its `main` branch. Enable GitHub Actions and permit the workflow's public heartbeat commit (`contents: write`). In repository Settings → Pages, select GitHub Actions as the source.
3. Run the `Verified public calendar relay` workflow. Confirm its first real-source build and Pages deployment succeed. Tests use explicitly synthetic BLS fixtures; passing tests alone does not establish real-source coverage.
4. Inspect the deployed `latest.json`, `calendar_bundle.json`, `calendar_bundle.sha256`, and `source_manifest.json`. The endpoint will have the form `https://OWNER.github.io/REPOSITORY/`; that is a template, not a published endpoint.
5. On the consuming PC, set only `base_url` in its local `operational_tools_v338i/calendar_relay_config.json` to the verified Pages base URL. Keep version 1 and the 36-hour maximum. The relay never reads local configuration or requests information from a consuming PC.
6. Run the existing data-only calendar maintenance task, or wait for its scheduled interval. Verify ACTIVE status and the actual published coverage. No daily acknowledgement or recurring file refresh is required after successful deployment/configuration.

Until deployment succeeds, the local updater retains its last known-good files, records an operator fault, and retries on schedule. Existing verified trading dates remain eligible under unchanged local gates; uncovered/expired dates remain blocked. A cloud runner can also receive a BLS access denial. That is a required-source fault, never permission to synthesize empty dates.

Local tests: `python -B -m unittest discover -s tests -v`.

Reference documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages and https://www.bls.gov/help/hlpiCAL.htm.
