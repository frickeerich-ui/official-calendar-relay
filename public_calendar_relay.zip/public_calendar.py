"""Public calendar data parser. No broker, account, credential or actor code."""
from datetime import date,datetime,time,timedelta,timezone
import calendar
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import uuid
from urllib.parse import urlparse
from zoneinfo import ZoneInfo


ET = ZoneInfo('America/New_York')

HOSTS = {'www.bls.gov', 'www.census.gov', 'www.federalreserve.gov', 'www.bea.gov', 'oui.doleta.gov', 'www.nyse.com'}

POLICY = 'Existing scheduled-release Tier-1 policy: selected BLS/Census national releases, industrial production, FOMC/Beige Book; -3/+5 minutes. Speeches and routine Fed balance-sheet tables are context, not new Tier-1 additions.'

BLS_ICS = 'https://www.bls.gov/schedule/news_release/bls.ics'

BLS_TZ = {'America/New_York', 'US/Eastern', 'US-Eastern', 'Eastern Standard Time'}

BLS_TITLES = ('Employment Situation', 'Consumer Price Index', 'Real Earnings', 'Producer Price Index', 'U.S. Import and Export Price Indexes', 'Import and Export Price Indexes', 'Metropolitan Area Employment and Unemployment', 'County Employment and Wages', 'Employment Cost Index', 'Employer Costs for Employee Compensation', 'Productivity and Costs', 'Total Factor Productivity', 'Multifactor Productivity', 'Workplace Injuries and Illnesses', 'Job Openings and Labor Turnover', 'State Job Openings and Labor Turnover', 'State Employment and Unemployment', 'Usual Weekly Earnings', 'Consumer Expenditures', 'Employment Projections', 'Business Employment Dynamics', 'Union Members', 'American Time Use', 'Foreign-Born Workers', 'Labor Force Characteristics', 'Employment Characteristics', 'Work Experience', 'Employee Benefits', 'Number of Jobs', 'Industry Productivity', 'Industry Labor Productivity', 'Persons with a Disability', 'Persons with Disabilities', "Women's Earnings", 'Highlights of Women', 'Volunteering', 'Job Flexibilities', 'Business Response Survey')

class InvalidCalendar(RuntimeError):
    pass

class SourceUnavailable(InvalidCalendar):
    pass

def require(condition, reason):
    if not condition:
        raise InvalidCalendar(reason)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def atomic(path, value):
    path = Path(path)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    data = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, indent=2).encode()
    try:
        with temp.open('xb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)

class Node:

    def __init__(self, tag='', attrs=()):
        self.tag = tag
        self.attrs = dict(attrs)
        self.parts = []

    def all(self, tag=None):
        for child in self.parts:
            if isinstance(child, Node):
                if tag is None or child.tag == tag:
                    yield child
                yield from child.all(tag)

    def text(self):
        return ' '.join(' '.join((p.text() if isinstance(p, Node) else p for p in self.parts)).split())

    def has_class(self, name):
        return name in self.attrs.get('class', '').split()

class Document(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self, data):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack = [self.root]
        self.feed(data.decode('utf-8', errors='strict'))

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs)
        self.stack[-1].parts.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if self.stack[-1].tag not in ('script', 'style'):
            self.stack[-1].parts.append(data)

def cells(row):
    return [p for p in row.parts if isinstance(p, Node) and p.tag in ('td', 'th')]

def parsed_date(text, year=None):
    text = re.sub('\\([^)]*\\)|\\*', '', text).strip()
    match = re.search('([A-Z][a-z]+)\\s+(\\d{1,2})(?:,\\s*(\\d{4}))?', text)
    require(match is not None, 'Unrecognized publication date: ' + text)
    month = list(calendar.month_name).index(match[1])
    y = int(match[3] or year or 0)
    require(y >= 2026, 'Missing/out-of-scope publication year')
    return date(y, month, int(match[2]))

def parsed_time(text):
    normalized = text.upper().replace('.', '').replace('EST', '').replace('EDT', '').replace('ET', '').strip()
    match = re.fullmatch('(\\d{1,2}):(\\d{2})\\s*([AP]M)', normalized)
    require(match is not None, 'Unverified/ambiguous release time: ' + text)
    h, m = (int(match[1]), int(match[2]))
    require(1 <= h <= 12 and 0 <= m < 60, 'Invalid release time')
    return time(h % 12 + (12 if match[3] == 'PM' else 0), m)

def event(day, clock, name, source, tier):
    require(bool(name.strip()), 'Unnamed release')
    return dict(dt=datetime.combine(day, parsed_time(clock), ET).isoformat(), name=name.strip(), source=source, tier=tier)

def bls_title(value):
    value = re.sub('\\s+', ' ', value).strip()
    if value == 'Import/Export Prices':
        return 'import and export price indexes'
    matches = [title for title in BLS_TITLES if value.casefold().startswith(title.casefold())]
    require(matches, 'Unrecognized BLS release title: ' + value[:100])
    return max(matches, key=len).casefold().removeprefix('u.s. ')

def ics_text(value):
    require(re.search('\\\\(?![nN,;\\\\])', value) is None, 'Unsupported iCalendar text escape')
    return re.sub('\\\\([nN,;\\\\])', lambda m: '\n' if m[1] in ('n', 'N') else m[1], value)

def ics_datetime(value, params, utc_only=False):
    require(set(params) <= {'TZID', 'VALUE'}, 'Unsupported iCalendar date parameters')
    require(params.get('VALUE', 'DATE-TIME') == 'DATE-TIME', 'BLS all-day/DATE release time is unverified')
    require(re.fullmatch('\\d{8}T\\d{6}Z?', value) is not None, 'Malformed iCalendar date/time')
    try:
        parsed = datetime.strptime(value.rstrip('Z'), '%Y%m%dT%H%M%S')
    except ValueError as exc:
        raise InvalidCalendar('Impossible iCalendar date/time') from exc
    if value.endswith('Z'):
        require('TZID' not in params, 'Conflicting UTC/TZID release time')
        return parsed.replace(tzinfo=timezone.utc)
    require(not utc_only and params.get('TZID') in BLS_TZ, 'Missing/unsupported BLS timezone')
    aware = parsed.replace(tzinfo=ET)
    require(aware.astimezone(timezone.utc).astimezone(ET).replace(tzinfo=None) == parsed, 'Nonexistent Eastern local time')
    require(aware.utcoffset() == parsed.replace(tzinfo=ET, fold=1).utcoffset(), 'Ambiguous Eastern local time')
    return aware

def parse_bls_ics(data, url, start, end, observed):
    require(url == BLS_ICS, 'Unapproved BLS iCalendar origin')
    require(observed.tzinfo is not None, 'Missing ICS observation timezone')
    try:
        text = data.decode('utf-8-sig', errors='strict')
    except UnicodeError as exc:
        raise InvalidCalendar('BLS ICS must be valid UTF-8') from exc
    require(len(data) < 10000000 and '\x00' not in text, 'Invalid/oversized BLS ICS')
    lines = []
    for line in text.replace('\r\n', '\n').split('\n'):
        require('\r' not in line and len(line) < 16384, 'Malformed iCalendar content line')
        if not line:
            continue
        if line[0] in ' \t':
            require(bool(lines), 'Orphan iCalendar continuation')
            lines[-1] += line[1:]
        else:
            lines.append(line)
    require(lines and lines[0] == 'BEGIN:VCALENDAR' and (lines[-1] == 'END:VCALENDAR'), 'Expected complete VCALENDAR')
    stack = []
    header = {}
    current = None
    components = []
    for line in lines:
        require(':' in line, 'Malformed iCalendar property')
        left, value = line.split(':', 1)
        parts = left.split(';')
        name = parts[0].upper()
        params = {}
        require(re.fullmatch('[A-Z0-9-]+', name) is not None, 'Invalid iCalendar property name')
        for part in parts[1:]:
            require('=' in part, 'Malformed iCalendar parameter')
            key, val = part.split('=', 1)
            key = key.upper()
            require(key not in params, 'Duplicate iCalendar parameter')
            params[key] = val.strip('"')
        if name == 'BEGIN':
            require(not params, 'Invalid component parameters')
            allowed = not stack and value == 'VCALENDAR' or (stack == ['VCALENDAR'] and value in ('VEVENT', 'VTIMEZONE')) or (len(stack) == 2 and stack[-1] == 'VTIMEZONE' and (value in ('STANDARD', 'DAYLIGHT')))
            require(allowed, 'Unsupported/nested iCalendar component')
            stack.append(value)
            if value == 'VEVENT':
                current = {}
        elif name == 'END':
            require(not params and stack and (stack[-1] == value), 'Mismatched iCalendar component end')
            if value == 'VEVENT':
                components.append(current)
                current = None
            stack.pop()
        elif stack == ['VCALENDAR']:
            require(name not in header, 'Duplicate iCalendar header')
            header[name] = (params, value)
        elif stack == ['VCALENDAR', 'VEVENT']:
            require(name not in current, 'Duplicate event property: ' + name)
            current[name] = (params, value)
        else:
            require(len(stack) >= 2 and stack[1] == 'VTIMEZONE', 'Property outside calendar component')
    require(not stack and header.get('VERSION') == ({}, '2.0'), 'Unsupported/missing iCalendar VERSION')
    product = header.get('PRODID', ({}, ''))[1]
    require(re.search('\\bBLS\\b|Bureau of Labor Statistics', product, re.I), 'Missing BLS calendar product identity')
    require(header.get('METHOD', ({}, 'PUBLISH'))[1] == 'PUBLISH', 'Unsupported calendar method')
    require(0 < len(components) <= 5000, 'Empty/oversized BLS event set')
    output = []
    uids = set()
    identities = set()
    families = set()
    for props in components:
        require({'UID', 'DTSTAMP', 'DTSTART', 'SUMMARY'} <= set(props), 'Incomplete BLS VEVENT')
        require(not {'RRULE', 'RDATE', 'EXDATE', 'RECURRENCE-ID', 'EXRULE'} & set(props), 'Recurring BLS event requires explicit-date review')
        require(props.get('STATUS', ({}, 'CONFIRMED'))[1] == 'CONFIRMED', 'Unconfirmed/cancelled BLS release')
        uid = props['UID'][1]
        require(uid and uid not in uids, 'Duplicate/empty BLS event UID')
        uids.add(uid)
        for field in ('DTSTAMP', 'CREATED', 'LAST-MODIFIED'):
            if field in props:
                params, value = props[field]
                stamp = ics_datetime(value, params, utc_only=True)
                require(stamp <= observed + timedelta(minutes=5), 'Future BLS calendar timestamp')
        params, value = props['DTSTART']
        at = ics_datetime(value, params).astimezone(ET)
        require(2000 <= at.year <= observed.year + 2, 'Out-of-scope BLS event year')
        require(at.weekday() < 5 and time(6) <= at.time().replace(tzinfo=None) <= time(18), 'Implausible BLS release weekday/time')
        require(not props['SUMMARY'][0], 'Unexpected BLS SUMMARY parameters')
        title = ics_text(props['SUMMARY'][1])
        family = bls_title(title)
        if 'DTEND' in props:
            params, value = props['DTEND']
            finish = ics_datetime(value, params)
            require(timedelta(0) <= finish - at <= timedelta(days=1), 'Invalid BLS event duration')
        if 'DURATION' in props:
            require('DTEND' not in props and re.fullmatch('PT(?:0M|[0-5]?\\dM|[01]?\\dH)', props['DURATION'][1]), 'Unsupported BLS event duration')
        identity = (at.isoformat(), family)
        require(identity not in identities, 'Duplicate BLS release event')
        identities.add(identity)
        if start.year == at.year:
            families.add(family)
        output.append(dict(dt=at.isoformat(), name=title, source=url, tier=1))
    days = [datetime.fromisoformat(row['dt']).date() for row in output]
    require(min(days) <= start and max(days) >= end, 'Stale/truncated BLS feed does not bracket requested coverage')
    require({'employment situation', 'consumer price index', 'producer price index'} <= families, 'BLS current-year core release families missing; cannot infer no-event dates')
    require(any((start - timedelta(days=45) <= d <= end for d in days)), 'BLS feed lacks contemporary release dates')
    return output

def parse_bls(data, url, year, month):
    doc = Document(data).root
    headings = [n.text() for tag in ('h1', 'h2', 'title') for n in doc.all(tag)]
    require(any((f'{calendar.month_name[month]} {year}' in h for h in headings)), 'BLS month/year heading missing')
    tables = [t for t in doc.all('table') if any(([n.text().lower() for n in cells(r)][:3] == ['date', 'time', 'release'] for r in t.all('tr')))]
    require(len(tables) == 1, 'BLS uniquely identified Date/Time/Release table required')
    output = []
    holiday_rows = 0
    recognized = 0
    for row in tables[0].all('tr'):
        c = cells(row)
        if not c or c[0].tag == 'th':
            continue
        require(len(c) == 3 and re.search('[A-Z][a-z]+\\s+\\d{1,2},\\s*' + str(year), c[0].text()), 'BLS unparsed/ambiguous release row; no partial coverage')
        day = parsed_date(c[0].text())
        require(day.year == year and day.month == month, 'BLS row outside requested month')
        clock, name = (c[1].text(), c[2].text())
        recognized += 1
        if not clock and any((word in name for word in ('Day', 'Holiday'))):
            holiday_rows += 1
            continue
        output.append(event(day, clock, name, url, 1))
    require(recognized > 0 and output, 'BLS release table unavailable or empty; no inferred no-event coverage')
    return output

def parse_census(data, url, year):
    doc = Document(data).root
    require(f'{year} Economic Indicator' in doc.text(), 'Census annual heading missing')
    output = []
    for row in doc.all('tr'):
        c = cells(row)
        if len(c) < 4:
            continue
        rawdate = c[1].text()
        if rawdate.lower() == 'suspended':
            continue
        if c[0].tag == 'th':
            continue
        require(re.search('[A-Z][a-z]+\\s+\\d{1,2},\\s*' + str(year), rawdate), 'Census unparsed publication date; no partial coverage')
        day = parsed_date(rawdate)
        output.append(event(day, c[2].text(), c[0].text(), url, 1))
    require(len(output) >= 12, 'Census annual table incomplete/unrecognized')
    return output

def parse_fed(data, url, year, month):
    doc = Document(data).root
    require(f'{calendar.month_name[month]} {year}' in doc.text(), 'Fed month/year heading missing')
    output = []
    panels = 0
    category = ''
    for panel in doc.all():
        if panel.tag == 'h4':
            label = panel.text()
            if label in ('Speeches', 'FOMC Meetings', 'Beige Book', 'Statistical Releases'):
                category = label
        if panel.tag != 'div':
            continue
        if not panel.has_class('panel-body'):
            continue
        columns = [n for n in panel.all('div') if any((n.has_class(x) for x in ('col-xs-2', 'col-xs-7', 'col-xs-3')))]
        if len(columns) != 3:
            continue
        clock, name, daytext = (n.text() for n in columns)
        panels += 1
        selected = bool(category == 'FOMC Meetings' and 'fomc' in name.lower() or (category == 'Beige Book' and 'beige book' in name.lower()) or (category == 'Statistical Releases' and 'industrial production' in name.lower()))
        if not selected:
            continue
        require(re.fullmatch('\\d{1,2}', daytext) is not None, 'Ambiguous selected Fed release date')
        output.append(event(date(year, month, int(daytext)), clock, name, url, 1))
    require(panels > 0, 'Fed monthly event panels unavailable; cannot assert coverage')
    return output

def parse_bea(data, url, year):
    doc = Document(data).root
    tables = [t for t in doc.all('table') if t.attrs.get('id') == 'release-schedule-table']
    require(len(tables) == 1 and f'Year {year}' in tables[0].text(), 'BEA annual schedule schema/year missing')
    output = []
    for row in tables[0].all('tr'):
        c = cells(row)
        if not c or c[0].tag == 'th':
            continue
        require(len(c) == 3, 'BEA unexpected schedule columns')
        dates = [n.text() for n in c[0].all('div') if n.has_class('release-date')]
        clocks = [n.text() for n in c[0].all('small')]
        require(len(dates) == len(clocks) == 1, 'BEA ambiguous date/time')
        output.append(event(parsed_date(dates[0], year), clocks[0], c[2].text(), url, 0))
    require(output, 'BEA release schedule unavailable')
    return output

def parse_dol(data, url, start, end):
    doc = Document(data).root
    text = doc.text()
    require('Thursday morning at 8:30am EST' in text and 'Exceptions to this schedule' in text, 'DOL authoritative recurrence/exception policy missing')
    exceptions = {}
    for row in doc.all('tr'):
        c = cells(row)
        if len(c) != 2 or not re.search('\\d{4}', c[0].text()):
            continue
        day = parsed_date(c[0].text())
        parsed_time(c[1].text())
        exceptions[day.isocalendar()[:2]] = (day, c[1].text())
    output = []
    for offset in range((end - start).days + 8):
        day = start + timedelta(days=offset)
        if day.weekday() != 3:
            continue
        actual, clock = exceptions.get(day.isocalendar()[:2], (day, '8:30 AM'))
        if start <= actual <= end:
            output.append(event(actual, clock, 'Weekly Unemployment Insurance Claims', url, 1))
    return output

def parse_nyse(data, url, years):
    doc = Document(data).root
    tables = list(doc.all('table'))
    holidays = {}
    early = {}
    require('Core Trading Session: 9:30' in doc.text() and '4:00 p.m.' in doc.text(), 'NYSE core-session hours not verified')
    for year in years:
        found = False
        for table in tables:
            rows = list(table.all('tr'))
            if not rows:
                continue
            header = [c.text() for c in cells(rows[0])]
            if 'Holiday' not in header or str(year) not in header:
                continue
            index = header.index(str(year))
            days = set()
            for row in rows[1:]:
                c = cells(row)
                require(len(c) > index, 'NYSE holiday table truncated')
                text = c[index].text()
                if text.strip().startswith(('—', '-')):
                    require(year == 2028 and 'New Year' in c[0].text(), 'Unrecognized omitted NYSE holiday')
                    continue
                days.add(parsed_date(text, year))
            require(len(days) >= 9, 'NYSE holiday year incomplete')
            holidays[year] = days
            found = True
            break
        require(found, 'NYSE verified holiday year unavailable: ' + str(year))
    for node in doc.all('p'):
        text = node.text()
        if 'Each market will close early at 1:00 p.m.' not in text:
            continue
        for match in re.finditer('([A-Z][a-z]+)\\s+(\\d{1,2}),\\s*(\\d{4})', text):
            day = parsed_date(match.group())
            if day.year in years:
                early[day] = time(13)
    require(early, 'NYSE early-close footnotes unavailable; do not assume normal close')
    return (holidays, early)

def urls_for(start, end):
    urls = dict(bea='https://www.bea.gov/news/schedule/', dol='https://oui.doleta.gov/unemploy/claims_arch.asp', nyse='https://www.nyse.com/trade/hours-calendars', bls_ics=BLS_ICS)
    for year in range(start.year, end.year + 1):
        urls[f'census_{year}'] = f'https://www.census.gov/economic-indicators/calendar-listview-{year}.html'
    months = {(start + timedelta(days=i)).replace(day=1) for i in range((end - start).days + 1)}
    for month in sorted(months):
        key = month.strftime('%Y_%m')
        urls['fed_' + key] = f'https://www.federalreserve.gov/newsevents/{month.year}-{calendar.month_name[month.month].lower()}.htm'
    return urls

def bls_secondary_urls(start, end):
    months = {(start + timedelta(days=i)).replace(day=1) for i in range((end - start).days + 1)}
    return {'bls_html_' + m.strftime('%Y_%m'): f'https://www.bls.gov/schedule/{m.year}/{m.month:02d}_sched_list.htm' for m in sorted(months)}

class Capture(bytes):

    def __new__(cls, data, metadata):
        value = super().__new__(cls, data)
        value.metadata = metadata
        return value

def fetch(url):
    import requests
    parts = urlparse(url)
    require(parts.scheme == 'https' and parts.hostname in HOSTS and (parts.netloc == parts.hostname) and (not parts.query) and (not parts.fragment), 'URL outside approved calendar-data source policy')
    if parts.hostname == 'www.bls.gov':
        require(url == BLS_ICS or re.fullmatch('/schedule/\\d{4}/\\d{2}_sched_list.htm', parts.path), 'Unapproved BLS calendar path')
    try:
        response = requests.get(url, timeout=(5, 15), allow_redirects=False, stream=True, headers={'User-Agent': 'AlpacaPaperCalendarMaintenance/1.1 (public calendar data verification)', 'Accept': 'text/calendar' if url == BLS_ICS else 'text/html'})
    except requests.RequestException as exc:
        raise SourceUnavailable('Authoritative retrieval ' + type(exc).__name__ + ': ' + url) from exc
    with response:
        if response.status_code != 200:
            raise SourceUnavailable(f'Authoritative source HTTP {response.status_code}: {url}')
        kind = response.headers.get('Content-Type', '').split(';', 1)[0].strip().lower()
        require(kind == ('text/calendar' if url == BLS_ICS else 'text/html'), 'Unexpected source content type: ' + url)
        chunks = []
        length = 0
        for chunk in response.iter_content(65536):
            length += len(chunk)
            require(length < 10000000, 'Oversized authoritative source')
            chunks.append(chunk)
        data = b''.join(chunks)
        require((100 if url == BLS_ICS else 1000) < len(data), 'Unexpected source length: ' + url)
        return Capture(data, dict(http_status=response.status_code, content_type=kind, http_date=response.headers.get('Date'), last_modified=response.headers.get('Last-Modified')))

def bls_events(start, end, sources, observed):
    secondary = bls_secondary_urls(start, end)
    parsed = {}
    for key, url in secondary.items():
        if key in sources:
            _, _, year, month = key.split('_')
            parsed[key] = parse_bls(sources[key], url, int(year), int(month))
    if 'bls_ics' in sources:
        rows = parse_bls_ics(sources['bls_ics'], BLS_ICS, start, end, observed)
        for key, other in parsed.items():
            month = key[-7:].replace('_', '-')

            def identities(items):
                return {(r['dt'], bls_title(r['name'])) for r in items if start <= datetime.fromisoformat(r['dt']).date() <= end and r['dt'].startswith(month)}
            require(identities(rows) == identities(other), 'Official BLS ICS/HTML cross-check disagreement: ' + key)
        return rows
    require(set(parsed) == set(secondary), 'BLS feed unavailable and complete official fallback unavailable')
    rows = [r for values in parsed.values() for r in values]
    for row in rows:
        bls_title(row['name'])
    return rows

def build(start, end, sources, observed):
    expected = urls_for(start, end)
    secondary = bls_secondary_urls(start, end)
    require(set(expected) - {'bls_ics'} <= set(sources), 'Missing source capture; no partial-source verification')
    require(set(sources) <= set(expected) | set(secondary), 'Unexpected/unapproved calendar capture')
    require(end >= start and (end - start).days <= 14, 'Invalid coverage horizon')
    events = bls_events(start, end, sources, observed)
    provenance = {}
    holidays, early = parse_nyse(sources['nyse'], expected['nyse'], set(range(start.year, end.year + 1)))
    active = {key: url for key, url in (expected | secondary).items() if key in sources}
    for key, url in active.items():
        data = sources[key]
        provenance[key] = dict(url=url, retrieved_at=observed.isoformat(), sha256=sha(data))
        if key.startswith('fed_'):
            _, year, month = key.split('_')
            events += parse_fed(data, url, int(year), int(month))
        elif key.startswith('census_'):
            events += parse_census(data, url, int(key.split('_')[1]))
        elif key == 'bea':
            require(start.year == end.year, 'BEA year-boundary coverage requires separately verified annual publication')
            bea = parse_bea(data, url, start.year)
            require(max((datetime.fromisoformat(r['dt']).date() for r in bea)) >= end, 'BEA published future horizon does not cover requested end')
            events += bea
        elif key == 'dol':
            events += parse_dol(data, url, start, end)
    require(observed.tzinfo is not None, 'Missing retrieval timezone')
    valid_until = datetime.combine(end, time(23, 59, 59), ET).isoformat()
    macro_days = {}
    session_days = {}
    closures = {}
    for i in range((end - start).days + 1):
        day = start + timedelta(days=i)
        key = day.isoformat()
        if day.weekday() >= 5 or day in holidays[day.year]:
            closures[key] = dict(verified=True, reason='WEEKEND' if day.weekday() >= 5 else 'NYSE_PUBLISHED_HOLIDAY', source=expected['nyse'], retrieved_at=observed.isoformat())
            continue
        opened = datetime.combine(day, time(9, 30), ET)
        closed = datetime.combine(day, early.get(day, time(16)), ET)
        session_days[key] = dict(verified=True, source=expected['nyse'], retrieved_at=observed.isoformat(), open=opened.isoformat(), close=closed.isoformat())
        rows = {(r['dt'], r['name'], r['source']): r for r in events if datetime.fromisoformat(r['dt']).date() == day}
        selected = sorted(rows.values(), key=lambda r: (r['dt'], r['name']))
        macro_days[key] = dict(verified=True, verified_no_events=not selected, events=selected, policy=POLICY, sources=list(active.values()), source_verification=provenance, retrieved_at=observed.isoformat(), valid_until=valid_until)
    require(macro_days and set(macro_days) == set(session_days), 'No complete paired trading-date coverage')
    generation = uuid.uuid4().hex
    return (dict(version=1, generation=generation, days=macro_days, source_provenance=provenance), dict(version=1, generation=generation, days=session_days, closures=closures, source_provenance=provenance))
